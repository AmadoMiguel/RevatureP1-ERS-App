package com.ers.ERSProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ErsProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
